'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  IconLayoutDashboard, IconShieldLock, IconUsers,
  IconUserCircle, IconId, IconBus, IconSettings,
  IconFileText, IconLogout
} from '@tabler/icons-react';
import useAuth from '../hooks/useAuth';

const menuItems = [
  { label: 'Dashboard', href: '/dashboard', icon: IconLayoutDashboard, kode: 'dashboard' },
  { label: 'Kelola Role', href: '/roles', icon: IconShieldLock, kode: 'roles' },
  { label: 'Kelola User', href: '/users', icon: IconUsers, kode: 'users' },
  { label: 'My Profile', href: '/profile', icon: IconUserCircle, kode: 'profile' },
  { label: 'Data Pegawai', href: '/pegawai', icon: IconId, kode: 'pegawai' },
  { label: 'Tunjangan Transport', href: '/tunjangan', icon: IconBus, kode: 'tunjangan' },
  { label: 'Setting Tunjangan', href: '/setting-tunjangan', icon: IconSettings, kode: 'setting_tunjangan' },
  { label: 'Log Aktivitas', href: '/log', icon: IconFileText, kode: 'log' },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { user, hasAccess, logout } = useAuth();

  return (
    <aside className="navbar navbar-vertical navbar-expand-lg">
      <div className="container-fluid">
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-menu">
          <span className="navbar-toggler-icon" />
        </button>
        <h1 className="navbar-brand navbar-brand-autodark">
          <span className="fw-bold text-primary">JMC</span>
          <span className="text-muted ms-1 fs-4">Kepegawaian</span>
        </h1>
        <div className="collapse navbar-collapse" id="navbar-menu">
          <ul className="navbar-nav pt-lg-3">
            {menuItems.map((item) => {
              if (!hasAccess(item.kode)) return null;
              const active = pathname.startsWith(item.href);
              return (
                <li key={item.href} className="nav-item">
                  <Link href={item.href} className={`nav-link ${active ? 'active' : ''}`}>
                    <span className="nav-link-icon d-md-none d-lg-inline-block">
                      <item.icon size={20} />
                    </span>
                    <span className="nav-link-title">{item.label}</span>
                  </Link>
                </li>
              );
            })}
          </ul>
          <div className="mt-auto p-3 border-top">
            <div className="d-flex align-items-center mb-2">
              <div className="avatar avatar-sm me-2 bg-primary-lt">
                {user?.nama?.[0]?.toUpperCase()}
              </div>
              <div>
                <div className="fw-semibold lh-1">{user?.nama}</div>
                <div className="text-muted small">{user?.nama_role}</div>
              </div>
            </div>
            <button className="btn btn-outline-danger btn-sm w-100" onClick={logout}>
              <IconLogout size={16} className="me-1" />Logout
            </button>
          </div>
        </div>
      </div>
    </aside>
  );
}