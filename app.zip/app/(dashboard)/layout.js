import AuthGuard from '../components/AuthGuard';
import Sidebar from '../components/Sidebar';

export default function DashboardLayout({ children }) {
  return (
    <AuthGuard>
      <div className="page">
        <Sidebar />
        <div className="page-wrapper">
          <div className="page-body">
            <div className="container-xl">
              {children}
            </div>
          </div>
        </div>
      </div>
    </AuthGuard>
  );
}