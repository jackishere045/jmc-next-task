'use client';
import { useEffect, useState } from 'react';
import { IconUsers, IconUserCheck, IconUserX, IconSchool } from '@tabler/icons-react';
import dynamic from 'next/dynamic';
import api from '../../lib/axios';
import useAuth from '../../hooks/useAuth';
import Link from 'next/link';

const Chart = dynamic(() => import('react-apexcharts'), { ssr: false });

export default function DashboardPage() {
  const { user } = useAuth();
  const [stats, setStats] = useState(null);

  useEffect(() => {
    if (user?.id_role === 2) {
      api.get('/pegawai/dashboard-stats').then(r => setStats(r.data.data));
    }
  }, [user]);

  // Superadmin & Admin HRD
  if (!user || user.id_role !== 2) {
    return (
      <div className="page-header mb-4">
        <div className="page-title">
          <h2 className="mb-0">Selamat Datang, {user?.nama} — {user?.nama_role}</h2>
        </div>
      </div>
    );
  }

  // Manager HRD dashboard
  return (
    <>
      <div className="page-header mb-4">
        <div className="page-title">
          <h2 className="mb-0">Dashboard Manager HRD</h2>
        </div>
      </div>

      {stats && (
        <>
          {/* Widget cards */}
          <div className="row row-deck row-cards mb-4">
            {[
              { label: 'Total Pegawai', value: stats.total, icon: IconUsers, color: 'blue' },
              { label: 'Pegawai Kontrak', value: stats.kontrak, icon: IconUserX, color: 'orange' },
              { label: 'Pegawai Tetap', value: stats.tetap, icon: IconUserCheck, color: 'green' },
              { label: 'Peserta Magang', value: stats.magang, icon: IconSchool, color: 'purple' },
            ].map((w) => (
              <div key={w.label} className="col-sm-6 col-lg-3">
                <div className="card">
                  <div className="card-body">
                    <div className="d-flex align-items-center">
                      <div className={`avatar bg-${w.color}-lt me-3`}>
                        <w.icon size={24} className={`text-${w.color}`} />
                      </div>
                      <div>
                        <div className="text-muted small">{w.label}</div>
                        <div className="fs-2 fw-bold">{w.value}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Charts */}
          <div className="row mb-4">
            <div className="col-md-6">
              <div className="card">
                <div className="card-header"><h3 className="card-title">Status Kontrak</h3></div>
                <div className="card-body">
                  <Chart type="donut"
                    options={{ labels: ['Kontrak', 'Tetap', 'Magang'], legend: { position: 'bottom' } }}
                    series={[stats.kontrak, stats.tetap, stats.magang]}
                    height={250}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Tabel 5 pegawai terbaru */}
          <div className="card">
            <div className="card-header"><h3 className="card-title">5 Pegawai Terbaru</h3></div>
            <div className="table-responsive">
              <table className="table table-vcenter">
                <thead>
                  <tr>
                    <th>Nama</th><th>Jabatan</th><th>Tgl Masuk</th><th>Kontrak</th><th>Aksi</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.terbaru?.map(p => (
                    <tr key={p.id}>
                      <td>{p.nama_pegawai}</td>
                      <td>{p.jabatan}</td>
                      <td>{new Date(p.tanggal_masuk).toLocaleDateString('id-ID')}</td>
                      <td><span className={`badge bg-${p.status_kontrak === 'tetap' ? 'success' : 'warning'}-lt text-${p.status_kontrak === 'tetap' ? 'success' : 'warning'}`}>{p.status_kontrak}</span></td>
                      <td><Link href={`/pegawai/${p.id}`} className="btn btn-sm btn-outline-primary">Detail</Link></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </>
  );
}