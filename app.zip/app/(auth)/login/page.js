'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import api from '../../lib/axios';
import toast, { Toaster } from 'react-hot-toast';

export default function LoginPage() {
  const router = useRouter();
  const [form, setForm] = useState({ identifier: '', password: '', captcha: '', rememberMe: false });
  const [captchaData, setCaptchaData] = useState({ sessionId: '', captcha: '' });
  const [loading, setLoading] = useState(false);
  const [showPass, setShowPass] = useState(false);

  useEffect(() => {
    fetchCaptcha();
    // Redirect kalau sudah login
    const token = localStorage.getItem('token');
    if (token) router.replace('/dashboard');
  }, []);

  const fetchCaptcha = async () => {
    try {
      const { data } = await api.get('/auth/captcha');
      setCaptchaData({ sessionId: data.sessionId, captcha: data.captcha });
    } catch {
      toast.error('Gagal memuat captcha');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.captcha) return toast.error('Captcha wajib diisi');

    setLoading(true);
    try {
      const { data } = await api.post('/auth/login', {
        identifier: form.identifier,
        password: form.password,
        captcha: form.captcha,
        captchaSessionId: captchaData.sessionId,
        rememberMe: form.rememberMe,
      });

      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      localStorage.setItem('lastActivity', Date.now().toString());
      if (form.rememberMe) localStorage.setItem('rememberMe', 'true');

      // Ambil permissions
      const me = await api.get('/auth/me');
      localStorage.setItem('permissions', JSON.stringify(me.data.data.permissions));

      toast.success('Login berhasil!');
      router.replace('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login gagal');
      fetchCaptcha();
      setForm(f => ({ ...f, captcha: '' }));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page page-center">
      <Toaster position="top-right" />
      <div className="container container-tight py-4">
        <div className="text-center mb-4">
          <h2 className="fw-bold text-primary mb-0">JMC</h2>
          <p className="text-muted">Sistem Informasi Kepegawaian</p>
        </div>
        <div className="card card-md">
          <div className="card-body">
            <h2 className="h2 text-center mb-4">Masuk ke akun Anda</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label className="form-label">Username / Email / No. HP</label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Masukkan username, email, atau no. HP"
                  value={form.identifier}
                  onChange={e => setForm(f => ({ ...f, identifier: e.target.value }))}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-label">Password</label>
                <div className="input-group input-group-flat">
                  <input
                    type={showPass ? 'text' : 'password'}
                    className="form-control"
                    placeholder="Password"
                    value={form.password}
                    onChange={e => setForm(f => ({ ...f, password: e.target.value }))}
                    required
                  />
                  <span className="input-group-text" style={{ cursor: 'pointer' }} onClick={() => setShowPass(s => !s)}>
                    {showPass ? '🙈' : '👁️'}
                  </span>
                </div>
              </div>
              <div className="mb-3">
                <label className="form-label">Captcha</label>
                <div className="d-flex align-items-center gap-3 mb-2">
                  <div className="bg-dark text-white px-4 py-2 rounded fw-bold fs-4 letter-spacing-wide"
                    style={{ letterSpacing: '0.3em', fontFamily: 'monospace', userSelect: 'none' }}>
                    {captchaData.captcha}
                  </div>
                  <button type="button" className="btn btn-sm btn-outline-secondary" onClick={fetchCaptcha}>
                    🔄 Refresh
                  </button>
                </div>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Ketik kode captcha di atas"
                  value={form.captcha}
                  onChange={e => setForm(f => ({ ...f, captcha: e.target.value.toUpperCase() }))}
                  maxLength={5}
                  required
                />
              </div>
              <div className="mb-3">
                <label className="form-check">
                  <input
                    type="checkbox"
                    className="form-check-input"
                    checked={form.rememberMe}
                    onChange={e => setForm(f => ({ ...f, rememberMe: e.target.checked }))}
                  />
                  <span className="form-check-label">Remember me (jangan auto logout)</span>
                </label>
              </div>
              <div className="form-footer">
                <button type="submit" className="btn btn-primary w-100" disabled={loading}>
                  {loading ? <span className="spinner-border spinner-border-sm me-2" /> : null}
                  {loading ? 'Memproses...' : 'Masuk'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}